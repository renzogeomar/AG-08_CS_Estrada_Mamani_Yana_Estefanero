---
title: "Guía de commits AG-10 para 4 personas"
---

# Guía rápida: subir AG-10 al repositorio entre 4 (≈ 15 minutos)

**Idea central:** cada persona trabaja en **su propia rama** y toca **archivos distintos**. Así no hay conflictos y los cuatro avanzan a la vez. Todo el contenido ya está hecho en el ZIP `ag10-repo.zip`; cada quien solo copia sus archivos, hace commit y push.

## 0. Reparto (según Tabla 2 del caso)

| Persona | Rol | Rama | Archivos que le tocan |
|---|---|---|---|
| 1 | Facilitador/a ADD | `ag10/facilitador-utilidad-bitacora` | `utilidad.md`, `bitacora-ia.md`, `README.md`, imágenes de utilidad/escenario |
| 2 | Arquitecto/a | `ag10/arquitecto-alternativas-poc` | `alternativas.md`, imágenes de alternativas, `src/ag10/**`, `scripts/ag10-ejecutar.*` |
| 3 | Redactor/a | `ag10/redactor-adr-c4` | `ADR-010-…md`, `workspace.dsl`, `exportado/`, imágenes C4 y fuentes `.dot` |
| 4 | Evaluador/a | `ag10/evaluador-evaluacion-cruzada` | `evaluacion-cruzada.md`, informe `.docx` |

Convención de ramas: `ag10/<rol>-<tema>` en minúsculas y con guiones. Convención de commits: `tipo(ámbito): descripción en minúscula, en presente` (`docs`, `feat`, `test`, `build`, `chore`).

## 1. Preparación (las 4 personas, una sola vez)

```bash
git clone <URL-del-repo> && cd <carpeta-del-repo>
git config user.name  "Tu Nombre y Apellido"
git config user.email "tu-correo@unsa.edu.pe"
git checkout main && git pull

# Descomprime el ZIP FUERA del repo (por ejemplo en ~/ag10-zip)
unzip -o ag10-repo.zip -d ~/ag10-zip
REPO="$(pwd)"        # guarda la ruta del repo para copiar
```

> En Windows usa **Git Bash**. Si no tienes `unzip`, descomprime con el explorador a `C:\ag10-zip` y usa `cd /c/ag10-zip`.

**Antes de empezar:** mira cuál es el siguiente número libre de ADR (`ls docs/architecture/adr`). Si ya existe `ADR-010`, la Persona 3 renombra el archivo y cambia el título (ver paso 5).

---

## 2. Persona 1 · Facilitador/a (utilidad + bitácora)

```bash
git checkout -b ag10/facilitador-utilidad-bitacora
cd ~/ag10-zip
cp -r --parents \
  docs/architecture/ruta-colca/ag10/utilidad.md \
  docs/architecture/ruta-colca/ag10/bitacora-ia.md \
  docs/architecture/ruta-colca/ag10/README.md \
  docs/architecture/ruta-colca/ag10/img/utilidad.png \
  docs/architecture/ruta-colca/ag10/img/escenario.png \
  docs/architecture/ruta-colca/ag10/img/ag08-contenedores.png "$REPO"/
cd "$REPO"
```

**Antes del commit:** abre `bitacora-ia.md` y reemplaza `[Nombre N]` por quien realmente verificó cada prompt. Rellena `[N.° de grupo]` en `utilidad.md`.

```bash
git add docs/architecture/ruta-colca/ag10/utilidad.md \
        docs/architecture/ruta-colca/ag10/img/utilidad.png \
        docs/architecture/ruta-colca/ag10/img/escenario.png \
        docs/architecture/ruta-colca/ag10/img/ag08-contenedores.png
git commit -m "docs(ag10): agrega árbol de utilidad y escenario E2 completo"

git add docs/architecture/ruta-colca/ag10/bitacora-ia.md
git commit -m "docs(ag10): registra la bitácora de uso de IA (P1 a P5)"

git add docs/architecture/ruta-colca/ag10/README.md
git commit -m "docs(ag10): agrega índice de entregables de la iteración"

git push -u origin ag10/facilitador-utilidad-bitacora
```

---

## 3. Persona 2 · Arquitecto/a (alternativas + prueba de concepto)

```bash
git checkout main && git checkout -b ag10/arquitecto-alternativas-poc
cd ~/ag10-zip
cp -r --parents \
  docs/architecture/ruta-colca/ag10/alternativas.md \
  docs/architecture/ruta-colca/ag10/img/alternativa-a.png \
  docs/architecture/ruta-colca/ag10/img/alternativa-b.png \
  docs/architecture/ruta-colca/ag10/img/estados-reserva.png \
  src/ag10 scripts/ag10-ejecutar.sh scripts/ag10-ejecutar.bat "$REPO"/
cd "$REPO"

# Comprueba que todo pasa ANTES de commitear (requiere JDK 21)
bash scripts/ag10-ejecutar.sh        # Windows cmd: scripts\ag10-ejecutar.bat
# Debe terminar con: "Todas las pruebas pasaron." y "OK: dominio y aplicación..."
echo "out/" >> .gitignore             # no subir las clases compiladas
```

```bash
git add docs/architecture/ruta-colca/ag10/alternativas.md docs/architecture/ruta-colca/ag10/img/alternativa-*.png docs/architecture/ruta-colca/ag10/img/estados-reserva.png
git commit -m "docs(ag10): compara alternativas A (outbox) y B (cola) para E2"

git add src/ag10/dominio src/ag10/aplicacion src/ag10/infraestructura
git commit -m "feat(ag10): agrega prueba de concepto de reintento de cobros con outbox"

git add src/ag10/prueba
git commit -m "test(ag10): prueba la caída de la pasarela con adaptadores en memoria"

git add src/ag10/arquitectura
git commit -m "test(ag10): agrega función de aptitud ReglaDependencias"

git add scripts/ag10-ejecutar.sh scripts/ag10-ejecutar.bat .gitignore
git commit -m "build(ag10): agrega scripts para compilar y ejecutar la prueba de concepto"

git push -u origin ag10/arquitecto-alternativas-poc
```

---

## 4. Persona 3 · Redactor/a (ADR + C4)

```bash
git checkout main && git checkout -b ag10/redactor-adr-c4
cd ~/ag10-zip
cp -r --parents \
  docs/architecture/adr/ADR-010-reintento-de-cobros-con-outbox.md \
  docs/architecture/c4/ruta-colca \
  docs/architecture/ruta-colca/ag10/img/c4-*.png \
  docs/architecture/ruta-colca/ag10/img/fuentes "$REPO"/
cd "$REPO"
```

> **Ojo:** esto reemplaza tu `workspace.dsl` de AG-08 por el actualizado. Si tu AG-08 tenía elementos extra (otros contenedores, personas), usa `git diff` y fusiona a mano: los cambios nuevos están marcados con `// AG-10` y con la etiqueta `"AG-10"`.

**Valida y exporta con la Structurizr CLI (obligatorio, no se pudo ejecutar al preparar el ZIP):**

```bash
cd docs/architecture/c4/ruta-colca
docker run --rm -v "$PWD:/usr/local/structurizr" structurizr/cli validate -workspace workspace.dsl
docker run --rm -v "$PWD:/usr/local/structurizr" structurizr/cli export -workspace workspace.dsl -format plantuml -output exportado
cd "$REPO"
```

Si `validate` marca un error, es casi seguro de sintaxis en una línea concreta: corrígela y repite. Pega la salida de `validate` en el informe (sección 6). Si cambias el número del ADR, hazlo así:

```bash
git mv docs/architecture/adr/ADR-010-reintento-de-cobros-con-outbox.md docs/architecture/adr/ADR-0NN-reintento-de-cobros-con-outbox.md
# y cambia "ADR-010" por "ADR-0NN" dentro del archivo
```

```bash
git add docs/architecture/adr/
git commit -m "docs(adr): registra ADR-010 reintento de cobros con outbox (E2)"

git add docs/architecture/c4/ruta-colca/workspace.dsl
git commit -m "docs(c4): actualiza workspace.dsl con procesador de tareas y vista dinámica de E2"

git add docs/architecture/c4/ruta-colca/exportado
git commit -m "docs(c4): exporta las vistas con Structurizr CLI"

git add docs/architecture/ruta-colca/ag10/img/c4-*.png docs/architecture/ruta-colca/ag10/img/fuentes
git commit -m "docs(ag10): agrega diagramas C4 y sus fuentes"

git push -u origin ag10/redactor-adr-c4
```

---

## 5. Persona 4 · Evaluador/a (evaluación cruzada + informe)

```bash
git checkout main && git checkout -b ag10/evaluador-evaluacion-cruzada
cd ~/ag10-zip
cp -r --parents \
  docs/architecture/ruta-colca/ag10/evaluacion-cruzada.md \
  docs/architecture/ruta-colca/ag10/informe "$REPO"/
cd "$REPO"
```

**En clase:** completa la tabla B de `evaluacion-cruzada.md` (`[completar]`) con los hallazgos reales del ADR del grupo vecino (el escenario siguiente: E2 → E3).

```bash
git add docs/architecture/ruta-colca/ag10/evaluacion-cruzada.md
git commit -m "docs(ag10): agrega evaluación ATAM propia y del ADR del grupo vecino"

git add docs/architecture/ruta-colca/ag10/informe
git commit -m "docs(ag10): agrega informe de resolución en Word"

git push -u origin ag10/evaluador-evaluacion-cruzada
```

---

## 6. Unir todo (Persona 1, 5 minutos)

Como nadie tocó los mismos archivos, el orden da igual.

1. En GitHub/GitLab abre un **Pull Request por rama hacia `main`** (4 PR). Título = mensaje del primer commit; descripción: «Entregables E_ del AG-10».
2. Cada PR lo **revisa otra persona** (1→2, 2→3, 3→4, 4→1) y lo aprueba.
3. Mergea con **Squash and merge** o **Merge commit** (como use tu curso; evita Rebase si no lo han practicado).
4. Al final:

```bash
git checkout main && git pull
bash scripts/ag10-ejecutar.sh          # última comprobación
git tag -a ag10-entrega -m "Entrega AG-10 (31/10/2026)"
git push origin ag10-entrega
```

## 7. Lista final antes de las 23:59

- [ ] Los 4 PR están en `main` y existen los 7 entregables (E1 a E7).
- [ ] `[Nombre N]`, `[N.° de grupo]` y `[Apellidos, Nombres]` reemplazados (informe, utilidad y bitácora).
- [ ] `structurizr validate` sin errores y `exportado/` con archivos.
- [ ] Evaluación del ADR del grupo vecino completada.
- [ ] `bash scripts/ag10-ejecutar.sh` termina en OK.
- [ ] La bitácora refleja lo que **de verdad** hicieron.

## 8. Si algo sale mal

| Problema | Solución |
|---|---|
| `error: pathspec ... did not match` | Estás en la carpeta equivocada: `cd "$REPO"` y revisa `git status`. |
| Copié un archivo que no era mío | `git restore --staged <archivo>` y no lo agregues. |
| Conflicto en `.gitignore` | Abre el archivo, deja ambas líneas (`out/` solo una vez) y `git add .gitignore && git commit`. |
| Push rechazado | `git pull --rebase origin <tu-rama>` y vuelve a hacer push. |
| Se subió algo por error | `git revert <hash>` (no reescribas historia en `main`). |
